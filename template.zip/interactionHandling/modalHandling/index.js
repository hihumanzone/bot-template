const { handleInputModal } = require('./inputModal');

module.exports = { handleInputModal };