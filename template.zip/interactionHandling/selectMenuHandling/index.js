const { handeMessagesMenu } = require('./messagesMenu');

module.exports = { handeMessagesMenu };