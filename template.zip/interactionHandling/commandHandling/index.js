const { handleCommand1 } = require('./command1');

module.exports = {
  handleCommand1
};